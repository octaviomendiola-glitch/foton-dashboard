# 🚛 FOTON Dashboard Ejecutivo – Soporte Técnico México

Aplicación móvil Flutter para visualización ejecutiva de casos de soporte técnico FOTON México.  
Compatible con **Android** e **iOS** · Procesamiento 100% local · Sin internet requerido.

---

## 📱 Pantallas

| Pantalla | Descripción |
|----------|-------------|
| **Inicio** | Splash FOTON + carga de archivo Excel |
| **Resumen Ejecutivo** | KPIs, tendencia mensual, gráficas de estatus |
| **Análisis de Tiempos** | Estadísticas, semáforo verde/amarillo/rojo, histograma |
| **Distribuidores** | Top 10, ranking completo con % cumplimiento |
| **Fallas & Calidad** | Pareto, heatmap distribuidor×falla, modelos |
| **Detalle** | Tabla con búsqueda, ordenamiento, paginación, export |

---

## 🏗️ Estructura del Proyecto

```
lib/
├── main.dart                    # Entry point
├── models/
│   └── caso_model.dart          # CasoModel, DashboardStats, DistribuidorRanking
├── services/
│   ├── excel_service.dart       # Lectura y parseo de .xlsx
│   └── export_service.dart      # Exportación PDF y CSV
├── providers/
│   └── dashboard_provider.dart  # Estado global con filtros
├── screens/
│   ├── home_screen.dart         # Pantalla inicial con file picker
│   ├── dashboard_screen.dart    # Contenedor principal + tab Resumen
│   ├── tiempos_screen.dart      # Análisis de tiempos
│   ├── distribuidores_screen.dart
│   ├── fallas_screen.dart
│   └── detalle_screen.dart      # Tabla detallada
├── widgets/
│   ├── kpi_card.dart
│   ├── chart_card.dart
│   ├── filter_bar.dart
│   ├── ranking_table.dart
│   └── semaforo_widget.dart
├── themes/
│   └── app_theme.dart           # Colores FOTON + tema oscuro
└── utils/
    └── constants.dart           # Keywords detección columnas
```

---

## 🚀 Cómo compilar

### Requisitos
- Flutter SDK 3.10+
- Dart 3.0+
- Android Studio / Xcode

### Pasos

```bash
# 1. Clonar / descomprimir el proyecto
cd foton_dashboard

# 2. Instalar dependencias
flutter pub get

# 3. Verificar dispositivo
flutter devices

# 4. Ejecutar en debug
flutter run

# 5. Build APK (Android)
flutter build apk --release --target-platform android-arm64
# APK en: build/app/outputs/flutter-apk/app-release.apk

# 6. Build AAB para Play Store
flutter build appbundle --release

# 7. Build iOS (requiere Mac + Xcode)
flutter build ios --release
```

---

## 🎨 Identidad Visual FOTON

| Token | Color | Hex |
|-------|-------|-----|
| Navy | Azul marino | `#003087` |
| Blue | Azul corporativo | `#0057B8` |
| Electric | Azul eléctrico | `#0080E8` |
| Accent | Azul claro | `#00AAFF` |
| Verde | Semáforo ok | `#00D97E` |
| Amarillo | Semáforo alerta | `#FFBE2E` |
| Rojo | Semáforo crítico | `#E8364A` |

---

## 📊 Detección automática de columnas

El servicio Excel detecta columnas por palabras clave (sin importar el nombre exacto):

| Campo | Keywords detectadas |
|-------|-------------------|
| Caso | caso, ticket, folio, id, número |
| Fecha | fecha, date, apertura, inicio |
| Zona | zona, region, área, territorio |
| Distribuidor | distribuidor, dealer, concesionario |
| Modelo | modelo, model, unidad, vehículo |
| Falla | falla, tipo falla, problema, síntoma |
| Estatus | estatus, status, estado |
| Días | días, tiempo, atención, duración |
| Inmovilizante | inmovilizante, inmovil, critico |

Si no hay columna de días, los calcula automáticamente desde Fecha Apertura → Fecha Cierre (o hoy).

---

## 📦 Dependencias (100% gratuitas y open source)

| Paquete | Versión | Uso |
|---------|---------|-----|
| `provider` | ^6.1.1 | State management |
| `excel` | ^4.0.2 | Lectura de .xlsx |
| `file_picker` | ^6.1.1 | Selector de archivos |
| `fl_chart` | ^0.68.0 | Gráficas |
| `pdf` | ^3.10.8 | Generación PDF |
| `printing` | ^5.12.0 | Vista previa PDF |
| `share_plus` | ^7.2.2 | Compartir archivos |
| `path_provider` | ^2.1.2 | Rutas de archivos |
| `intl` | ^0.19.0 | Formato de fechas |

---

## 🔒 Privacidad

- **100% local**: los datos nunca salen del dispositivo
- **Sin red**: no requiere conexión a internet
- **Sin base de datos externa**: procesamiento en memoria

---

## 📋 KPIs calculados

- Total de Casos
- Casos Abiertos / Cerrados / % Cerrados
- Casos Inmovilizantes / % Inmovilizantes
- Tiempo Promedio / Máximo / Mínimo
- Distribuidores Activos / Modelos Afectados

## 📈 Estadísticas de tiempo

- Promedio · Mediana · Máximo · Mínimo
- Desviación Estándar · Percentil 90 · Percentil 95

## 🚦 Semáforo

| Color | Días |
|-------|------|
| 🟢 Verde | 0–3 días |
| 🟡 Amarillo | 4–7 días |
| 🔴 Rojo | Más de 7 días |

---

*FOTON Dashboard Ejecutivo v1.0.0 · FOTON México*
