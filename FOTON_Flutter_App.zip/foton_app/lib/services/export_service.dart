import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import '../models/caso_model.dart';

class ExportService {
  static Future<void> exportToPdf(
    List<CasoModel> casos,
    DashboardStats stats,
  ) async {
    final pdf = pw.Document();
    final now = DateTime.now();
    final dateStr =
        '${now.day.toString().padLeft(2, '0')}/${now.month.toString().padLeft(2, '0')}/${now.year}';

    // Cover page
    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (pw.Context context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Container(
                width: double.infinity,
                padding: const pw.EdgeInsets.all(24),
                decoration: pw.BoxDecoration(
                  color: PdfColors.blue900,
                  borderRadius: pw.BorderRadius.circular(8),
                ),
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text(
                      'FOTON',
                      style: pw.TextStyle(
                        color: PdfColors.white,
                        fontSize: 36,
                        fontWeight: pw.FontWeight.bold,
                        letterSpacing: 8,
                      ),
                    ),
                    pw.SizedBox(height: 8),
                    pw.Text(
                      'Dashboard Ejecutivo – Soporte Técnico México',
                      style: const pw.TextStyle(
                        color: PdfColors.white,
                        fontSize: 16,
                      ),
                    ),
                    pw.SizedBox(height: 4),
                    pw.Text(
                      'Generado: $dateStr',
                      style: const pw.TextStyle(
                        color: PdfColors.blue100,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              pw.SizedBox(height: 24),
              pw.Text(
                'KPIs Principales',
                style: pw.TextStyle(
                  fontSize: 18,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
              pw.SizedBox(height: 12),
              pw.GridView(
                crossAxisCount: 3,
                childAspectRatio: 2.5,
                children: [
                  _kpiCell('Total Casos', stats.total.toString()),
                  _kpiCell('Casos Abiertos', stats.abiertos.toString()),
                  _kpiCell('Casos Cerrados', stats.cerrados.toString()),
                  _kpiCell('% Cerrados', '${stats.pctCerrados.toStringAsFixed(1)}%'),
                  _kpiCell('Inmovilizantes', stats.inmovilizantes.toString()),
                  _kpiCell('% Inmovilizantes', '${stats.pctInmovilizantes.toStringAsFixed(1)}%'),
                  _kpiCell('Tiempo Prom.', stats.avgDias != null ? '${stats.avgDias!.toStringAsFixed(1)} d' : '—'),
                  _kpiCell('Tiempo Máx.', stats.maxDias != null ? '${stats.maxDias!.toStringAsFixed(0)} d' : '—'),
                  _kpiCell('Distribuidores', stats.distribuidores.toString()),
                ],
              ),
              pw.SizedBox(height: 24),
              pw.Text(
                'Semáforo de Atención',
                style: pw.TextStyle(
                  fontSize: 16,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
              pw.SizedBox(height: 12),
              pw.Row(
                children: [
                  _semaforoCell('Verde (0-3d)', stats.semaforoVerde, PdfColors.green700),
                  pw.SizedBox(width: 12),
                  _semaforoCell('Amarillo (4-7d)', stats.semaforoAmarillo, PdfColors.amber),
                  pw.SizedBox(width: 12),
                  _semaforoCell('Rojo (>7d)', stats.semaforoRojo, PdfColors.red700),
                ],
              ),
            ],
          );
        },
      ),
    );

    // Detail table page
    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4.landscape,
        build: (pw.Context context) {
          return [
            pw.Text(
              'Detalle de Casos',
              style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold),
            ),
            pw.SizedBox(height: 12),
            pw.TableHelper.fromTextArray(
              headers: ['Caso', 'Fecha', 'Zona', 'Distribuidor', 'Modelo', 'Estatus', 'Días'],
              data: casos.take(500).map((c) => [
                c.caso,
                c.fechaDisplay,
                c.zona,
                c.distribuidor.length > 18 ? '${c.distribuidor.substring(0, 18)}…' : c.distribuidor,
                c.modelo,
                c.estatus,
                c.diasDisplay,
              ]).toList(),
              headerStyle: pw.TextStyle(
                fontWeight: pw.FontWeight.bold,
                color: PdfColors.white,
                fontSize: 9,
              ),
              headerDecoration: const pw.BoxDecoration(color: PdfColors.blue900),
              rowDecoration: const pw.BoxDecoration(color: PdfColors.white),
              alternateRowDecoration: const pw.BoxDecoration(color: PdfColors.grey100),
              cellStyle: const pw.TextStyle(fontSize: 8),
              cellAlignments: {
                0: pw.Alignment.centerLeft,
                1: pw.Alignment.center,
                2: pw.Alignment.center,
                3: pw.Alignment.centerLeft,
                4: pw.Alignment.center,
                5: pw.Alignment.center,
                6: pw.Alignment.center,
              },
            ),
          ];
        },
      ),
    );

    final output = await getTemporaryDirectory();
    final file = File('${output.path}/FOTON_Dashboard_$dateStr.pdf');
    await file.writeAsBytes(await pdf.save());

    await Share.shareXFiles(
      [XFile(file.path)],
      subject: 'FOTON Dashboard – Soporte Técnico México',
    );
  }

  static pw.Widget _kpiCell(String label, String value) {
    return pw.Container(
      margin: const pw.EdgeInsets.all(4),
      padding: const pw.EdgeInsets.all(10),
      decoration: pw.BoxDecoration(
        color: PdfColors.blue50,
        borderRadius: pw.BorderRadius.circular(6),
        border: pw.Border.all(color: PdfColors.blue200),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(label, style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
          pw.SizedBox(height: 4),
          pw.Text(value, style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold, color: PdfColors.blue900)),
        ],
      ),
    );
  }

  static pw.Widget _semaforoCell(String label, int count, PdfColor color) {
    return pw.Expanded(
      child: pw.Container(
        padding: const pw.EdgeInsets.all(12),
        decoration: pw.BoxDecoration(
          color: color,
          borderRadius: pw.BorderRadius.circular(8),
        ),
        child: pw.Column(
          children: [
            pw.Text(label, style: const pw.TextStyle(color: PdfColors.white, fontSize: 11)),
            pw.SizedBox(height: 6),
            pw.Text(count.toString(), style: pw.TextStyle(color: PdfColors.white, fontSize: 28, fontWeight: pw.FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  static Future<void> exportToExcel(List<CasoModel> casos) async {
    final sb = StringBuffer();
    // CSV export (universal spreadsheet compatibility)
    sb.writeln('Caso,Fecha,Zona,Distribuidor,Modelo,Tipo de Falla,Estatus,Responsable,Inmovilizante,Días Atención');
    for (final c in casos) {
      sb.writeln([
        _csvEscape(c.caso),
        _csvEscape(c.fechaDisplay),
        _csvEscape(c.zona),
        _csvEscape(c.distribuidor),
        _csvEscape(c.modelo),
        _csvEscape(c.falla),
        _csvEscape(c.estatus),
        _csvEscape(c.responsable),
        c.inmovilizante ? 'Sí' : 'No',
        c.dias?.toStringAsFixed(0) ?? '',
      ].join(','));
    }

    final output = await getTemporaryDirectory();
    final now = DateTime.now();
    final dateStr = '${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}';
    final file = File('${output.path}/FOTON_Export_$dateStr.csv');
    await file.writeAsString(sb.toString());

    await Share.shareXFiles(
      [XFile(file.path)],
      subject: 'FOTON Dashboard Export',
    );
  }

  static String _csvEscape(String s) {
    if (s.contains(',') || s.contains('"') || s.contains('\n')) {
      return '"${s.replaceAll('"', '""')}"';
    }
    return s;
  }
}
