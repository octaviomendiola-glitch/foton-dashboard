import 'dart:io';
import 'package:excel/excel.dart';
import '../models/caso_model.dart';
import '../utils/constants.dart';

class ExcelService {
  // Auto-detect column index by fuzzy-matching keywords
  static int? _detectColumn(List<String> headers, String fieldKey) {
    final keywords = AppConstants.columnKeywords[fieldKey] ?? [];
    for (int i = 0; i < headers.length; i++) {
      final h = headers[i].toLowerCase().trim();
      for (final kw in keywords) {
        if (h.contains(kw)) return i;
      }
    }
    return null;
  }

  static String _getCellValue(Data? cell) {
    if (cell == null) return '';
    final v = cell.value;
    if (v == null) return '';
    if (v is TextCellValue) return v.value.trim();
    if (v is IntCellValue) return v.value.toString();
    if (v is DoubleCellValue) return v.value.toString();
    if (v is BoolCellValue) return v.value ? '1' : '0';
    if (v is DateCellValue) {
      return '${v.year}-${v.month.toString().padLeft(2, '0')}-${v.day.toString().padLeft(2, '0')}';
    }
    if (v is DateTimeCellValue) {
      return '${v.year}-${v.month.toString().padLeft(2, '0')}-${v.day.toString().padLeft(2, '0')}';
    }
    return v.toString().trim();
  }

  static DateTime? _parseDate(String s) {
    if (s.isEmpty) return null;
    // Try ISO
    try { return DateTime.parse(s); } catch (_) {}
    // Try dd/mm/yyyy
    final parts = s.split(RegExp(r'[/\-\.]'));
    if (parts.length == 3) {
      try {
        final a = int.parse(parts[0]);
        final b = int.parse(parts[1]);
        final c = int.parse(parts[2]);
        if (c > 1900) return DateTime(c, b, a); // dd/mm/yyyy
        if (a > 1900) return DateTime(a, b, c); // yyyy/mm/dd
      } catch (_) {}
    }
    return null;
  }

  static double? _parseDouble(String s) {
    if (s.isEmpty) return null;
    final cleaned = s.replaceAll(',', '.').replaceAll(RegExp(r'[^\d.]'), '');
    return double.tryParse(cleaned);
  }

  static bool _isInmovilizante(String v) {
    final lower = v.toLowerCase().trim();
    return AppConstants.inmovilizanteKeywords.contains(lower);
  }

  /// Main parse function - returns list of CasoModel
  static Future<List<CasoModel>> parseFile(String filePath) async {
    final bytes = await File(filePath).readAsBytes();
    final excel = Excel.decodeBytes(bytes);

    // Use first sheet
    final sheetName = excel.tables.keys.first;
    final sheet = excel.tables[sheetName]!;

    if (sheet.rows.isEmpty) return [];

    // Get headers from first row
    final headerRow = sheet.rows.first;
    final headers = headerRow.map((c) => _getCellValue(c)).toList();

    // Detect columns
    final colCaso = _detectColumn(headers, 'caso');
    final colFecha = _detectColumn(headers, 'fecha');
    final colZona = _detectColumn(headers, 'zona');
    final colDist = _detectColumn(headers, 'distribuidor');
    final colModelo = _detectColumn(headers, 'modelo');
    final colFalla = _detectColumn(headers, 'falla');
    final colEstatus = _detectColumn(headers, 'estatus');
    final colResp = _detectColumn(headers, 'responsable');
    final colDias = _detectColumn(headers, 'dias');
    final colInmov = _detectColumn(headers, 'inmovilizante');
    final colCierre = _detectColumn(headers, 'cierre');

    final casos = <CasoModel>[];

    for (int i = 1; i < sheet.rows.length; i++) {
      final row = sheet.rows[i];
      if (row.isEmpty) continue;

      String get(int? col) =>
          col != null && col < row.length ? _getCellValue(row[col]) : '';

      // Skip completely empty rows
      final rowStr = row.map((c) => _getCellValue(c)).join('');
      if (rowStr.isEmpty) continue;

      // Parse fecha
      DateTime? fecha;
      final fechaStr = get(colFecha);
      if (fechaStr.isNotEmpty) {
        fecha = _parseDate(fechaStr);
      }

      // Parse dias – compute from dates if no explicit column
      double? dias = _parseDouble(get(colDias));
      if (dias == null && fecha != null) {
        DateTime? cierre;
        final cierreStr = get(colCierre);
        if (cierreStr.isNotEmpty) {
          cierre = _parseDate(cierreStr);
        }
        cierre ??= DateTime.now();
        dias = cierre.difference(fecha).inDays.toDouble();
        if (dias < 0) dias = 0;
      }

      // Build raw data map
      final rawData = <String, dynamic>{};
      for (int j = 0; j < headers.length && j < row.length; j++) {
        rawData[headers[j]] = _getCellValue(row[j]);
      }

      casos.add(CasoModel(
        caso: get(colCaso).isNotEmpty ? get(colCaso) : 'C${i.toString().padLeft(4, '0')}',
        fecha: fecha,
        zona: get(colZona),
        distribuidor: get(colDist),
        modelo: get(colModelo),
        falla: get(colFalla),
        estatus: get(colEstatus),
        responsable: get(colResp),
        inmovilizante: _isInmovilizante(get(colInmov)),
        dias: dias,
        rawData: rawData,
      ));
    }

    return casos;
  }
}
