import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import '../providers/dashboard_provider.dart';
import '../themes/app_theme.dart';
import '../widgets/chart_card.dart';
import '../widgets/ranking_table.dart';

class DistribuidoresScreen extends StatelessWidget {
  const DistribuidoresScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.watch<DashboardProvider>();
    final ranking = p.ranking;
    final maxTotal = ranking.isEmpty ? 1 : ranking.map((r) => r.total).reduce((a, b) => a > b ? a : b);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Top 10 Bar chart
          SizedBox(
            height: 280,
            child: ChartCard(
              title: 'Top 10 Distribuidores con Más Casos',
              child: _Top10Chart(data: p.casosPorDistribuidor),
            ),
          ),
          const SizedBox(height: 16),

          // Ranking table
          _sectionTitle('Ranking Completo de Distribuidores'),
          const SizedBox(height: 10),
          Container(
            decoration: BoxDecoration(
              color: AppTheme.bgCard,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppTheme.borderColor),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: RankingTable(ranking: ranking, maxTotal: maxTotal),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String text) {
    return Row(
      children: [
        Container(
          width: 3, height: 16,
          decoration: BoxDecoration(
            gradient: AppTheme.accentGradient,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 8),
        Text(text, style: const TextStyle(
          fontSize: 13, fontWeight: FontWeight.w700, color: AppTheme.textPrimary,
        )),
      ],
    );
  }
}

extension on DashboardProvider {
  Map<String, int> get casosPorDistribuidor {
    final map = <String, int>{};
    for (final c in filteredCasos) {
      if (c.distribuidor.isEmpty) continue;
      map[c.distribuidor] = (map[c.distribuidor] ?? 0) + 1;
    }
    return map;
  }
}

class _Top10Chart extends StatelessWidget {
  final Map<String, int> data;
  const _Top10Chart({required this.data});

  @override
  Widget build(BuildContext context) {
    if (data.isEmpty) {
      return const Center(
        child: Text('Sin datos', style: TextStyle(color: AppTheme.textSecondary)),
      );
    }
    final top = (data.entries.toList()..sort((a, b) => b.value.compareTo(a.value))).take(10).toList();
    final maxY = top.first.value.toDouble();

    return BarChart(
      BarChartData(
        alignment: BarChartAlignment.spaceAround,
        maxY: maxY * 1.2,
        barTouchData: BarTouchData(
          touchTooltipData: BarTouchTooltipData(
            getTooltipColor: (_) => AppTheme.bgCard2,
            getTooltipItem: (group, _, rod, __) => BarTooltipItem(
              '${top[group.x].key}\n${rod.toY.toInt()} casos',
              const TextStyle(color: AppTheme.textPrimary, fontSize: 11),
            ),
          ),
        ),
        titlesData: FlTitlesData(
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 40,
              getTitlesWidget: (v, _) {
                final i = v.toInt();
                if (i < 0 || i >= top.length) return const SizedBox();
                final label = top[i].key;
                return Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    label.length > 10 ? '${label.substring(0, 10)}…' : label,
                    style: const TextStyle(color: AppTheme.textSecondary, fontSize: 8),
                    textAlign: TextAlign.center,
                    maxLines: 2,
                  ),
                );
              },
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 28,
              getTitlesWidget: (v, _) => Text(
                v.toInt().toString(),
                style: const TextStyle(color: AppTheme.textSecondary, fontSize: 9),
              ),
            ),
          ),
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          getDrawingHorizontalLine: (_) => const FlLine(color: AppTheme.borderColor, strokeWidth: 0.5),
        ),
        borderData: FlBorderData(show: false),
        barGroups: top.asMap().entries.map((e) => BarChartGroupData(
          x: e.key,
          barRods: [
            BarChartRodData(
              toY: e.value.value.toDouble(),
              gradient: const LinearGradient(
                colors: [AppTheme.fotonNavy, AppTheme.fotonAccent],
                begin: Alignment.bottomCenter,
                end: Alignment.topCenter,
              ),
              width: 22,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
            ),
          ],
        )).toList(),
      ),
    );
  }
}
