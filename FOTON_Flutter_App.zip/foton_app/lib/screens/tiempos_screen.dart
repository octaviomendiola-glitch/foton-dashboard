import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import '../providers/dashboard_provider.dart';
import '../themes/app_theme.dart';
import '../widgets/semaforo_widget.dart';
import '../widgets/chart_card.dart';

class TiemposScreen extends StatelessWidget {
  const TiemposScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.watch<DashboardProvider>();
    final stats = p.stats;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Stats grid
          _sectionTitle('Estadísticas de Tiempo de Atención'),
          const SizedBox(height: 10),
          _statsGrid(stats),
          const SizedBox(height: 20),

          // Semaforo
          _sectionTitle('Semáforo de Atención'),
          const SizedBox(height: 10),
          SemaforoWidget(
            verde: stats.semaforoVerde,
            amarillo: stats.semaforoAmarillo,
            rojo: stats.semaforoRojo,
          ),
          const SizedBox(height: 20),

          // Tiempo por distribuidor
          _sectionTitle('Tiempo Promedio por Distribuidor'),
          const SizedBox(height: 10),
          SizedBox(
            height: 300,
            child: ChartCard(
              title: 'Días promedio (Top 15)',
              child: _TiempoDistChart(data: p.tiempoPorDistribuidor),
            ),
          ),
          const SizedBox(height: 16),

          // Histograma
          _sectionTitle('Distribución de Días de Atención'),
          const SizedBox(height: 10),
          SizedBox(
            height: 240,
            child: ChartCard(
              title: 'Histograma',
              child: _HistogramaChart(casos: p.filteredCasos),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String text) {
    return Row(
      children: [
        Container(
          width: 3, height: 16,
          decoration: BoxDecoration(
            gradient: AppTheme.accentGradient,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 8),
        Text(
          text,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: AppTheme.textPrimary,
          ),
        ),
      ],
    );
  }

  Widget _statsGrid(stats) {
    final items = [
      ('Promedio', stats.avgDias != null ? '${stats.avgDias!.toStringAsFixed(1)} d' : '—'),
      ('Mediana', stats.mediana != null ? '${stats.mediana!.toStringAsFixed(1)} d' : '—'),
      ('Máximo', stats.maxDias != null ? '${stats.maxDias!.toStringAsFixed(0)} d' : '—'),
      ('Mínimo', stats.minDias != null ? '${stats.minDias!.toStringAsFixed(0)} d' : '—'),
      ('Desv. Estándar', stats.stdDev != null ? '${stats.stdDev!.toStringAsFixed(1)} d' : '—'),
      ('Percentil 90', stats.p90 != null ? '${stats.p90!.toStringAsFixed(0)} d' : '—'),
      ('Percentil 95', stats.p95 != null ? '${stats.p95!.toStringAsFixed(0)} d' : '—'),
      ('N Casos', stats.total.toString()),
    ];

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.borderColor),
      ),
      padding: const EdgeInsets.all(16),
      child: Wrap(
        spacing: 0, runSpacing: 0,
        children: items.map((item) {
          return SizedBox(
            width: 120,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    item.$1.toUpperCase(),
                    style: const TextStyle(
                      fontSize: 9,
                      color: AppTheme.textSecondary,
                      letterSpacing: 0.8,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    item.$2,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.fotonAccent,
                    ),
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

class _TiempoDistChart extends StatelessWidget {
  final Map<String, double> data;
  const _TiempoDistChart({required this.data});

  @override
  Widget build(BuildContext context) {
    if (data.isEmpty) {
      return const Center(
        child: Text('Sin datos', style: TextStyle(color: AppTheme.textSecondary)),
      );
    }
    final top = data.entries.take(15).toList();

    return BarChart(
      BarChartData(
        alignment: BarChartAlignment.spaceAround,
        maxY: (top.map((e) => e.value).reduce((a, b) => a > b ? a : b)) * 1.2,
        barTouchData: BarTouchData(
          touchTooltipData: BarTouchTooltipData(
            getTooltipColor: (_) => AppTheme.bgCard2,
            getTooltipItem: (group, _, rod, __) => BarTooltipItem(
              '${top[group.x].key}\n${rod.toY.toStringAsFixed(1)} días',
              const TextStyle(color: AppTheme.textPrimary, fontSize: 11),
            ),
          ),
        ),
        titlesData: FlTitlesData(
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 36,
              getTitlesWidget: (v, _) {
                final i = v.toInt();
                if (i < 0 || i >= top.length) return const SizedBox();
                final label = top[i].key;
                return Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    label.length > 9 ? '${label.substring(0, 9)}…' : label,
                    style: const TextStyle(color: AppTheme.textSecondary, fontSize: 8),
                    textAlign: TextAlign.center,
                  ),
                );
              },
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 28,
              getTitlesWidget: (v, _) => Text(
                '${v.toInt()}d',
                style: const TextStyle(color: AppTheme.textSecondary, fontSize: 8),
              ),
            ),
          ),
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          getDrawingHorizontalLine: (_) => const FlLine(color: AppTheme.borderColor, strokeWidth: 0.5),
        ),
        borderData: FlBorderData(show: false),
        barGroups: top.asMap().entries.map((e) {
          final days = e.value.value;
          final color = days <= 3
              ? AppTheme.semaforoGreen
              : days <= 7
                  ? AppTheme.semaforoYellow
                  : AppTheme.semaforoRed;
          return BarChartGroupData(
            x: e.key,
            barRods: [
              BarChartRodData(
                toY: days,
                color: color,
                width: 16,
                borderRadius: BorderRadius.circular(3),
              ),
            ],
          );
        }).toList(),
      ),
    );
  }
}

class _HistogramaChart extends StatelessWidget {
  final List casos;
  const _HistogramaChart({required this.casos});

  @override
  Widget build(BuildContext context) {
    final diasArr = casos
        .map((c) => c.dias)
        .where((d) => d != null)
        .map((d) => (d as double))
        .toList();
    if (diasArr.isEmpty) {
      return const Center(
        child: Text('Sin datos', style: TextStyle(color: AppTheme.textSecondary)),
      );
    }

    final buckets = [0, 1, 2, 3, 4, 5, 6, 7, 10, 15, 20, 30, 60];
    final counts = <int>[];
    final labels = <String>[];

    for (int i = 0; i < buckets.length - 1; i++) {
      labels.add('${buckets[i]}-${buckets[i + 1] - 1}');
      counts.add(diasArr.where((d) => d >= buckets[i] && d < buckets[i + 1]).length);
    }
    labels.add('${buckets.last}+');
    counts.add(diasArr.where((d) => d >= buckets.last).length);

    final maxY = counts.reduce((a, b) => a > b ? a : b).toDouble();

    return BarChart(
      BarChartData(
        alignment: BarChartAlignment.spaceAround,
        maxY: maxY * 1.2,
        barTouchData: BarTouchData(
          touchTooltipData: BarTouchTooltipData(
            getTooltipColor: (_) => AppTheme.bgCard2,
            getTooltipItem: (group, _, rod, __) => BarTooltipItem(
              '${labels[group.x]} días\n${rod.toY.toInt()} casos',
              const TextStyle(color: AppTheme.textPrimary, fontSize: 11),
            ),
          ),
        ),
        titlesData: FlTitlesData(
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 28,
              getTitlesWidget: (v, _) {
                final i = v.toInt();
                if (i < 0 || i >= labels.length) return const SizedBox();
                return Text(
                  labels[i],
                  style: const TextStyle(color: AppTheme.textSecondary, fontSize: 8),
                );
              },
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 28,
              getTitlesWidget: (v, _) => Text(
                v.toInt().toString(),
                style: const TextStyle(color: AppTheme.textSecondary, fontSize: 9),
              ),
            ),
          ),
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          getDrawingHorizontalLine: (_) => const FlLine(color: AppTheme.borderColor, strokeWidth: 0.5),
        ),
        borderData: FlBorderData(show: false),
        barGroups: counts.asMap().entries.map((e) {
          final bucketStart = e.key < buckets.length ? buckets[e.key] : buckets.last;
          final color = bucketStart <= 3
              ? AppTheme.semaforoGreen
              : bucketStart <= 7
                  ? AppTheme.semaforoYellow
                  : AppTheme.semaforoRed;
          return BarChartGroupData(
            x: e.key,
            barRods: [
              BarChartRodData(
                toY: e.value.toDouble(),
                color: color,
                width: 14,
                borderRadius: BorderRadius.circular(3),
              ),
            ],
          );
        }).toList(),
      ),
    );
  }
}
