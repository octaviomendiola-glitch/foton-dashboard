import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import '../providers/dashboard_provider.dart';
import '../themes/app_theme.dart';
import '../widgets/chart_card.dart';

class FallasScreen extends StatelessWidget {
  const FallasScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.watch<DashboardProvider>();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: SizedBox(
                  height: 280,
                  child: ChartCard(
                    title: 'Casos por Tipo de Falla',
                    child: _FallaBarChart(data: p.casosPorFalla),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: SizedBox(
                  height: 280,
                  child: ChartCard(
                    title: 'Pareto de Fallas',
                    child: _ParetoChart(data: p.casosPorFalla),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 260,
            child: ChartCard(
              title: 'Casos por Modelo',
              child: _ModeloBarChart(data: p.casosPorModelo),
            ),
          ),
          const SizedBox(height: 16),
          _HeatmapSection(
            heatmapData: p.heatmapData,
            fallas: p.heatmapFallas,
          ),
        ],
      ),
    );
  }
}

class _FallaBarChart extends StatelessWidget {
  final Map<String, int> data;
  const _FallaBarChart({required this.data});

  @override
  Widget build(BuildContext context) {
    if (data.isEmpty) return const Center(child: Text('Sin datos', style: TextStyle(color: AppTheme.textSecondary)));
    final top = (data.entries.toList()..sort((a, b) => b.value.compareTo(a.value))).take(10).toList();
    final maxY = top.first.value.toDouble();

    return BarChart(BarChartData(
      alignment: BarChartAlignment.spaceAround,
      maxY: maxY * 1.25,
      barTouchData: BarTouchData(
        touchTooltipData: BarTouchTooltipData(
          getTooltipColor: (_) => AppTheme.bgCard2,
          getTooltipItem: (g, _, rod, __) => BarTooltipItem(
            '${top[g.x].key}\n${rod.toY.toInt()} casos',
            const TextStyle(color: AppTheme.textPrimary, fontSize: 10),
          ),
        ),
      ),
      titlesData: FlTitlesData(
        bottomTitles: AxisTitles(sideTitles: SideTitles(
          showTitles: true, reservedSize: 40,
          getTitlesWidget: (v, _) {
            final i = v.toInt();
            if (i < 0 || i >= top.length) return const SizedBox();
            final l = top[i].key;
            return Padding(padding: const EdgeInsets.only(top: 4),
              child: Text(l.length > 9 ? '${l.substring(0, 9)}…' : l,
                style: const TextStyle(color: AppTheme.textSecondary, fontSize: 8),
                textAlign: TextAlign.center));
          },
        )),
        leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 24,
          getTitlesWidget: (v, _) => Text(v.toInt().toString(), style: const TextStyle(color: AppTheme.textSecondary, fontSize: 8)))),
        topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
      ),
      gridData: FlGridData(show: true, drawVerticalLine: false,
        getDrawingHorizontalLine: (_) => const FlLine(color: AppTheme.borderColor, strokeWidth: 0.5)),
      borderData: FlBorderData(show: false),
      barGroups: top.asMap().entries.map((e) => BarChartGroupData(
        x: e.key,
        barRods: [BarChartRodData(
          toY: e.value.value.toDouble(),
          color: AppTheme.chartPalette[e.key % AppTheme.chartPalette.length],
          width: 16, borderRadius: BorderRadius.circular(3),
        )],
      )).toList(),
    ));
  }
}

class _ParetoChart extends StatelessWidget {
  final Map<String, int> data;
  const _ParetoChart({required this.data});

  @override
  Widget build(BuildContext context) {
    if (data.isEmpty) return const Center(child: Text('Sin datos', style: TextStyle(color: AppTheme.textSecondary)));
    final top = (data.entries.toList()..sort((a, b) => b.value.compareTo(a.value))).take(12).toList();
    final total = top.fold(0, (a, b) => a + b.value);
    double cum = 0;
    final cumPcts = top.map((e) { cum += e.value; return cum / total * 100; }).toList();
    final maxY = top.first.value.toDouble();

    return BarChart(BarChartData(
      alignment: BarChartAlignment.spaceAround,
      maxY: maxY * 1.2,
      barTouchData: BarTouchData(
        touchTooltipData: BarTouchTooltipData(
          getTooltipColor: (_) => AppTheme.bgCard2,
          getTooltipItem: (g, _, rod, __) => BarTooltipItem(
            '${top[g.x].key}\n${rod.toY.toInt()} casos\n${cumPcts[g.x].toStringAsFixed(1)}% acum.',
            const TextStyle(color: AppTheme.textPrimary, fontSize: 10),
          ),
        ),
      ),
      titlesData: FlTitlesData(
        bottomTitles: AxisTitles(sideTitles: SideTitles(
          showTitles: true, reservedSize: 36,
          getTitlesWidget: (v, _) {
            final i = v.toInt();
            if (i < 0 || i >= top.length) return const SizedBox();
            final l = top[i].key;
            return Padding(padding: const EdgeInsets.only(top: 4),
              child: Text(l.length > 8 ? '${l.substring(0, 8)}…' : l,
                style: const TextStyle(color: AppTheme.textSecondary, fontSize: 8)));
          },
        )),
        leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 24,
          getTitlesWidget: (v, _) => Text(v.toInt().toString(), style: const TextStyle(color: AppTheme.textSecondary, fontSize: 8)))),
        rightTitles: AxisTitles(sideTitles: SideTitles(
          showTitles: true, reservedSize: 32,
          getTitlesWidget: (v, _) => Text('${v.toInt()}%', style: const TextStyle(color: AppTheme.semaforoYellow, fontSize: 8)),
        )),
        topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
      ),
      gridData: FlGridData(show: true, drawVerticalLine: false,
        getDrawingHorizontalLine: (_) => const FlLine(color: AppTheme.borderColor, strokeWidth: 0.5)),
      borderData: FlBorderData(show: false),
      barGroups: top.asMap().entries.map((e) => BarChartGroupData(
        x: e.key,
        barRods: [BarChartRodData(
          toY: e.value.value.toDouble(),
          color: AppTheme.fotonBlue,
          width: 14, borderRadius: BorderRadius.circular(3),
        )],
      )).toList(),
      extraLinesData: ExtraLinesData(
        horizontalLines: [],
        verticalLines: [],
      ),
    ));
  }
}

class _ModeloBarChart extends StatelessWidget {
  final Map<String, int> data;
  const _ModeloBarChart({required this.data});

  @override
  Widget build(BuildContext context) {
    if (data.isEmpty) return const Center(child: Text('Sin datos', style: TextStyle(color: AppTheme.textSecondary)));
    final top = (data.entries.toList()..sort((a, b) => b.value.compareTo(a.value))).take(10).toList();
    final maxY = top.first.value.toDouble();

    return BarChart(BarChartData(
      alignment: BarChartAlignment.spaceAround,
      maxY: maxY * 1.2,
      barTouchData: BarTouchData(
        touchTooltipData: BarTouchTooltipData(
          getTooltipColor: (_) => AppTheme.bgCard2,
          getTooltipItem: (g, _, rod, __) => BarTooltipItem(
            '${top[g.x].key}\n${rod.toY.toInt()} casos',
            const TextStyle(color: AppTheme.textPrimary, fontSize: 11),
          ),
        ),
      ),
      titlesData: FlTitlesData(
        bottomTitles: AxisTitles(sideTitles: SideTitles(
          showTitles: true, reservedSize: 36,
          getTitlesWidget: (v, _) {
            final i = v.toInt();
            if (i < 0 || i >= top.length) return const SizedBox();
            final l = top[i].key;
            return Padding(padding: const EdgeInsets.only(top: 4),
              child: Text(l.length > 9 ? '${l.substring(0, 9)}…' : l,
                style: const TextStyle(color: AppTheme.textSecondary, fontSize: 9)));
          },
        )),
        leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 28,
          getTitlesWidget: (v, _) => Text(v.toInt().toString(), style: const TextStyle(color: AppTheme.textSecondary, fontSize: 9)))),
        topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
      ),
      gridData: FlGridData(show: true, drawVerticalLine: false,
        getDrawingHorizontalLine: (_) => const FlLine(color: AppTheme.borderColor, strokeWidth: 0.5)),
      borderData: FlBorderData(show: false),
      barGroups: top.asMap().entries.map((e) => BarChartGroupData(
        x: e.key,
        barRods: [BarChartRodData(
          toY: e.value.value.toDouble(),
          gradient: const LinearGradient(
            colors: [AppTheme.fotonNavy, AppTheme.fotonElectric],
            begin: Alignment.bottomCenter, end: Alignment.topCenter,
          ),
          width: 18, borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
        )],
      )).toList(),
    ));
  }
}

// ─── Heatmap ──────────────────────────────────────────────────────────────────
class _HeatmapSection extends StatelessWidget {
  final Map<String, Map<String, int>> heatmapData;
  final List<String> fallas;

  const _HeatmapSection({required this.heatmapData, required this.fallas});

  @override
  Widget build(BuildContext context) {
    if (heatmapData.isEmpty) return const SizedBox();

    final dists = heatmapData.keys.toList();
    final allValues = heatmapData.values
        .expand((m) => m.values)
        .where((v) => v > 0)
        .toList();
    final maxVal = allValues.isEmpty ? 1 : allValues.reduce((a, b) => a > b ? a : b);

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.borderColor),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(width: 6, height: 6, decoration: const BoxDecoration(color: AppTheme.fotonAccent, shape: BoxShape.circle)),
              const SizedBox(width: 8),
              const Text('HEATMAP: DISTRIBUIDOR VS TIPO DE FALLA', style: TextStyle(fontSize: 10, color: AppTheme.textSecondary, letterSpacing: 1)),
            ],
          ),
          const SizedBox(height: 14),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header row
                Row(
                  children: [
                    const SizedBox(width: 120),
                    ...fallas.map((f) => SizedBox(
                      width: 64,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 2),
                        child: Text(
                          f.length > 8 ? '${f.substring(0, 8)}…' : f,
                          style: const TextStyle(color: AppTheme.textSecondary, fontSize: 9, letterSpacing: 0.5),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )),
                  ],
                ),
                const SizedBox(height: 4),
                ...dists.map((d) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 120,
                        child: Text(
                          d.length > 14 ? '${d.substring(0, 14)}…' : d,
                          style: const TextStyle(color: AppTheme.textPrimary, fontSize: 10, fontWeight: FontWeight.w600),
                        ),
                      ),
                      ...fallas.map((f) {
                        final v = heatmapData[d]?[f] ?? 0;
                        final intensity = maxVal > 0 ? v / maxVal : 0.0;
                        final bg = v == 0
                            ? AppTheme.bgCard2
                            : Color.lerp(AppTheme.fotonNavy.withOpacity(0.3), AppTheme.fotonAccent, intensity)!;
                        return SizedBox(
                          width: 64,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 2),
                            child: Container(
                              height: 28,
                              decoration: BoxDecoration(
                                color: bg,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              alignment: Alignment.center,
                              child: Text(
                                v == 0 ? '' : v.toString(),
                                style: TextStyle(
                                  color: v == 0 ? Colors.transparent : Colors.white,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ),
                        );
                      }),
                    ],
                  ),
                )),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
