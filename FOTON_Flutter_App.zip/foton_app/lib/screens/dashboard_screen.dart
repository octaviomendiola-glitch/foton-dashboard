import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/dashboard_provider.dart';
import '../themes/app_theme.dart';
import '../widgets/filter_bar.dart';
import '../widgets/kpi_card.dart';
import '../services/export_service.dart';
import 'tiempos_screen.dart';
import 'distribuidores_screen.dart';
import 'fallas_screen.dart';
import 'detalle_screen.dart';
import '../widgets/chart_card.dart';
import 'package:fl_chart/fl_chart.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 0;

  static const _tabs = ['Resumen', 'Tiempos', 'Distribuidores', 'Fallas', 'Detalle'];
  static const _icons = [
    Icons.dashboard_outlined,
    Icons.schedule_outlined,
    Icons.business_outlined,
    Icons.build_outlined,
    Icons.table_rows_outlined,
  ];

  @override
  Widget build(BuildContext context) {
    final p = context.watch<DashboardProvider>();

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            ShaderMask(
              shaderCallback: (bounds) => AppTheme.fotonGradient.createShader(bounds),
              child: const Text(
                'FOTON',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 3,
                  fontSize: 18,
                ),
              ),
            ),
            const SizedBox(width: 12),
            const Text(
              'Dashboard Ejecutivo',
              style: TextStyle(color: AppTheme.textSecondary, fontSize: 13),
            ),
          ],
        ),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert, color: AppTheme.textSecondary),
            color: AppTheme.bgCard2,
            itemBuilder: (_) => [
              const PopupMenuItem(
                value: 'pdf',
                child: Row(children: [
                  Icon(Icons.picture_as_pdf, size: 16, color: AppTheme.semaforoRed),
                  SizedBox(width: 8),
                  Text('Exportar PDF', style: TextStyle(color: AppTheme.textPrimary, fontSize: 13)),
                ]),
              ),
              const PopupMenuItem(
                value: 'excel',
                child: Row(children: [
                  Icon(Icons.table_chart, size: 16, color: AppTheme.semaforoGreen),
                  SizedBox(width: 8),
                  Text('Exportar Excel/CSV', style: TextStyle(color: AppTheme.textPrimary, fontSize: 13)),
                ]),
              ),
            ],
            onSelected: (v) async {
              if (v == 'pdf') {
                await ExportService.exportToPdf(p.filteredCasos, p.stats);
              } else {
                await ExportService.exportToExcel(p.filteredCasos);
              }
            },
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(52),
          child: const FilterBar(),
        ),
      ),
      body: IndexedStack(
        index: _selectedIndex,
        children: const [
          _OverviewTab(),
          TiemposScreen(),
          DistribuidoresScreen(),
          FallasScreen(),
          DetalleScreen(),
        ],
      ),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: AppTheme.bgCard,
          border: Border(top: BorderSide(color: AppTheme.borderColor)),
        ),
        child: BottomNavigationBar(
          currentIndex: _selectedIndex,
          onTap: (i) => setState(() => _selectedIndex = i),
          items: List.generate(
            _tabs.length,
            (i) => BottomNavigationBarItem(
              icon: Icon(_icons[i], size: 20),
              label: _tabs[i],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Overview Tab ─────────────────────────────────────────────────────────────
class _OverviewTab extends StatelessWidget {
  const _OverviewTab();

  @override
  Widget build(BuildContext context) {
    final p = context.watch<DashboardProvider>();
    final stats = p.stats;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // KPI Grid
          _kpiGrid(stats),
          const SizedBox(height: 16),

          // Tendencia mensual
          SizedBox(
            height: 220,
            child: ChartCard(
              title: 'Tendencia Mensual de Casos',
              child: _TendenciaChart(data: p.casosPorMes),
            ),
          ),
          const SizedBox(height: 12),

          Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 220,
                  child: ChartCard(
                    title: 'Casos por Zona',
                    child: _BarChart(
                      data: p.casosPorZona,
                      horizontal: true,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: SizedBox(
                  height: 220,
                  child: ChartCard(
                    title: 'Abiertos vs Cerrados',
                    child: _DonutChart(
                      labels: ['Cerrados', 'Abiertos'],
                      values: [stats.cerrados.toDouble(), stats.abiertos.toDouble()],
                      colors: [AppTheme.semaforoGreen, AppTheme.semaforoRed],
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 220,
                  child: ChartCard(
                    title: 'Inmovilizantes vs No Inmovilizantes',
                    child: _DonutChart(
                      labels: ['Inmovilizante', 'No Inmovilizante'],
                      values: [stats.inmovilizantes.toDouble(), (stats.total - stats.inmovilizantes).toDouble()],
                      colors: [AppTheme.semaforoRed, AppTheme.fotonBlue],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: SizedBox(
                  height: 220,
                  child: ChartCard(
                    title: 'Top Modelos',
                    child: _BarChart(
                      data: _top(p.casosPorModelo, 6),
                      horizontal: true,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _kpiGrid(DashboardStats stats) {
    final kpis = [
      ('Total Casos', stats.total.toString(), Icons.folder_outlined, null),
      ('Abiertos', stats.abiertos.toString(), Icons.lock_open_outlined, AppTheme.semaforoYellow),
      ('Cerrados', stats.cerrados.toString(), Icons.check_circle_outline, AppTheme.semaforoGreen),
      ('% Cerrados', '${stats.pctCerrados.toStringAsFixed(1)}%', Icons.trending_up, AppTheme.semaforoGreen),
      ('Inmovilizantes', stats.inmovilizantes.toString(), Icons.warning_amber_outlined, stats.inmovilizantes > 0 ? AppTheme.semaforoRed : null),
      ('% Inmovilizantes', '${stats.pctInmovilizantes.toStringAsFixed(1)}%', Icons.priority_high, stats.inmovilizantes > 0 ? AppTheme.semaforoRed : null),
      ('Tpo Prom.', stats.avgDias != null ? '${stats.avgDias!.toStringAsFixed(1)}d' : '—', Icons.schedule, null),
      ('Tpo Máx.', stats.maxDias != null ? '${stats.maxDias!.toStringAsFixed(0)}d' : '—', Icons.timer_outlined, AppTheme.semaforoRed),
      ('Tpo Mín.', stats.minDias != null ? '${stats.minDias!.toStringAsFixed(0)}d' : '—', Icons.flash_on, AppTheme.semaforoGreen),
      ('Distribuidores', stats.distribuidores.toString(), Icons.business, null),
      ('Modelos', stats.modelos.toString(), Icons.directions_car_outlined, null),
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 2.2,
      ),
      itemCount: kpis.length,
      itemBuilder: (_, i) => KpiCard(
        label: kpis[i].$1,
        value: kpis[i].$2,
        icon: kpis[i].$3,
        accentColor: kpis[i].$4,
      ),
    );
  }

  Map<String, int> _top(Map<String, int> map, int n) {
    final sorted = map.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return Map.fromEntries(sorted.take(n));
  }
}

// ─── Charts ──────────────────────────────────────────────────────────────────
class _TendenciaChart extends StatelessWidget {
  final Map<String, int> data;
  const _TendenciaChart({required this.data});

  @override
  Widget build(BuildContext context) {
    if (data.isEmpty) return const _EmptyChart();
    final sorted = data.entries.toList()..sort((a, b) => a.key.compareTo(b.key));
    final spots = sorted.asMap().entries.map((e) =>
      FlSpot(e.key.toDouble(), e.value.value.toDouble())).toList();

    return LineChart(
      LineChartData(
        backgroundColor: Colors.transparent,
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          getDrawingHorizontalLine: (_) => const FlLine(
            color: AppTheme.borderColor,
            strokeWidth: 0.5,
          ),
        ),
        borderData: FlBorderData(show: false),
        titlesData: FlTitlesData(
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 32,
              getTitlesWidget: (v, _) => Text(
                v.toInt().toString(),
                style: const TextStyle(color: AppTheme.textSecondary, fontSize: 9),
              ),
            ),
          ),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 24,
              interval: (sorted.length / 6).ceilToDouble().clamp(1, 999),
              getTitlesWidget: (v, _) {
                final idx = v.toInt();
                if (idx < 0 || idx >= sorted.length) return const SizedBox();
                final parts = sorted[idx].key.split('-');
                return Text(
                  parts.length == 2 ? '${parts[1]}/${parts[0].substring(2)}' : sorted[idx].key,
                  style: const TextStyle(color: AppTheme.textSecondary, fontSize: 9),
                );
              },
            ),
          ),
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        lineBarsData: [
          LineChartBarData(
            spots: spots,
            isCurved: true,
            color: AppTheme.fotonAccent,
            barWidth: 2,
            dotData: const FlDotData(show: false),
            belowBarData: BarAreaData(
              show: true,
              color: AppTheme.fotonAccent.withOpacity(0.12),
            ),
          ),
        ],
        lineTouchData: LineTouchData(
          touchTooltipData: LineTouchTooltipData(
            getTooltipColor: (_) => AppTheme.bgCard2,
            getTooltipItems: (spots) => spots.map((s) {
              final idx = s.x.toInt();
              final label = idx < sorted.length ? sorted[idx].key : '';
              return LineTooltipItem(
                '$label\n${s.y.toInt()} casos',
                const TextStyle(color: AppTheme.textPrimary, fontSize: 11),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
}

class _BarChart extends StatelessWidget {
  final Map<String, int> data;
  final bool horizontal;
  const _BarChart({required this.data, this.horizontal = false});

  @override
  Widget build(BuildContext context) {
    if (data.isEmpty) return const _EmptyChart();
    final sorted = data.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final maxVal = sorted.first.value.toDouble();

    final groups = sorted.asMap().entries.map((e) =>
      BarChartGroupData(
        x: e.key,
        barRods: [
          BarChartRodData(
            toY: e.value.value.toDouble(),
            color: AppTheme.chartPalette[e.key % AppTheme.chartPalette.length],
            width: horizontal ? 14 : 16,
            borderRadius: BorderRadius.circular(3),
          ),
        ],
      ),
    ).toList();

    return BarChart(
      BarChartData(
        alignment: BarChartAlignment.spaceAround,
        maxY: maxVal * 1.2,
        barTouchData: BarTouchData(
          touchTooltipData: BarTouchTooltipData(
            getTooltipColor: (_) => AppTheme.bgCard2,
            getTooltipItem: (group, _, rod, __) => BarTooltipItem(
              '${sorted[group.x].key}\n${rod.toY.toInt()}',
              const TextStyle(color: AppTheme.textPrimary, fontSize: 11),
            ),
          ),
        ),
        titlesData: FlTitlesData(
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 32,
              getTitlesWidget: (v, _) {
                final i = v.toInt();
                if (i < 0 || i >= sorted.length) return const SizedBox();
                final label = sorted[i].key;
                return Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    label.length > 8 ? '${label.substring(0, 8)}…' : label,
                    style: const TextStyle(color: AppTheme.textSecondary, fontSize: 8),
                    textAlign: TextAlign.center,
                  ),
                );
              },
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 28,
              getTitlesWidget: (v, _) => Text(
                v.toInt().toString(),
                style: const TextStyle(color: AppTheme.textSecondary, fontSize: 8),
              ),
            ),
          ),
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          getDrawingHorizontalLine: (_) => const FlLine(color: AppTheme.borderColor, strokeWidth: 0.5),
        ),
        borderData: FlBorderData(show: false),
        barGroups: groups,
      ),
    );
  }
}

class _DonutChart extends StatefulWidget {
  final List<String> labels;
  final List<double> values;
  final List<Color> colors;
  const _DonutChart({required this.labels, required this.values, required this.colors});

  @override
  State<_DonutChart> createState() => _DonutChartState();
}

class _DonutChartState extends State<_DonutChart> {
  int? touchedIndex;

  @override
  Widget build(BuildContext context) {
    final total = widget.values.fold(0.0, (a, b) => a + b);
    if (total == 0) return const _EmptyChart();

    return Column(
      children: [
        Expanded(
          child: PieChart(
            PieChartData(
              pieTouchData: PieTouchData(
                touchCallback: (_, response) {
                  setState(() {
                    touchedIndex = response?.touchedSection?.touchedSectionIndex;
                  });
                },
              ),
              sectionsSpace: 2,
              centerSpaceRadius: 36,
              sections: widget.values.asMap().entries.map((e) {
                final isTouched = touchedIndex == e.key;
                return PieChartSectionData(
                  color: widget.colors[e.key % widget.colors.length],
                  value: e.value,
                  title: '',
                  radius: isTouched ? 52 : 44,
                );
              }).toList(),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 12, runSpacing: 4,
          alignment: WrapAlignment.center,
          children: widget.labels.asMap().entries.map((e) {
            final pct = total > 0 ? (widget.values[e.key] / total * 100).toStringAsFixed(1) : '0';
            return Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 8, height: 8,
                  decoration: BoxDecoration(
                    color: widget.colors[e.key % widget.colors.length],
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 4),
                Text(
                  '${e.value} $pct%',
                  style: const TextStyle(color: AppTheme.textSecondary, fontSize: 9),
                ),
              ],
            );
          }).toList(),
        ),
      ],
    );
  }
}

class _EmptyChart extends StatelessWidget {
  const _EmptyChart();
  @override
  Widget build(BuildContext context) => const Center(
    child: Text(
      'Sin datos',
      style: TextStyle(color: AppTheme.textSecondary, fontSize: 12),
    ),
  );
}
