import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/dashboard_provider.dart';
import '../models/caso_model.dart';
import '../themes/app_theme.dart';
import '../services/export_service.dart';
import '../utils/constants.dart';

class DetalleScreen extends StatefulWidget {
  const DetalleScreen({super.key});

  @override
  State<DetalleScreen> createState() => _DetalleScreenState();
}

class _DetalleScreenState extends State<DetalleScreen> {
  final _searchCtrl = TextEditingController();
  int _currentPage = 0;
  String _sortColumn = 'fecha';
  bool _sortAsc = false;

  List<CasoModel> _applySearch(List<CasoModel> all) {
    final q = _searchCtrl.text.toLowerCase();
    if (q.isEmpty) return all;
    return all.where((c) =>
      c.caso.toLowerCase().contains(q) ||
      c.distribuidor.toLowerCase().contains(q) ||
      c.zona.toLowerCase().contains(q) ||
      c.modelo.toLowerCase().contains(q) ||
      c.falla.toLowerCase().contains(q) ||
      c.estatus.toLowerCase().contains(q) ||
      c.responsable.toLowerCase().contains(q)
    ).toList();
  }

  List<CasoModel> _applySort(List<CasoModel> list) {
    list.sort((a, b) {
      int cmp;
      switch (_sortColumn) {
        case 'caso': cmp = a.caso.compareTo(b.caso); break;
        case 'fecha': cmp = (a.fecha ?? DateTime(2000)).compareTo(b.fecha ?? DateTime(2000)); break;
        case 'zona': cmp = a.zona.compareTo(b.zona); break;
        case 'distribuidor': cmp = a.distribuidor.compareTo(b.distribuidor); break;
        case 'modelo': cmp = a.modelo.compareTo(b.modelo); break;
        case 'estatus': cmp = a.estatus.compareTo(b.estatus); break;
        case 'dias': cmp = (a.dias ?? -1).compareTo(b.dias ?? -1); break;
        default: cmp = 0;
      }
      return _sortAsc ? cmp : -cmp;
    });
    return list;
  }

  void _sort(String col) {
    setState(() {
      if (_sortColumn == col) {
        _sortAsc = !_sortAsc;
      } else {
        _sortColumn = col;
        _sortAsc = true;
      }
      _currentPage = 0;
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.watch<DashboardProvider>();
    final searched = _applySort(_applySearch(List.from(p.filteredCasos)));
    final totalPages = (searched.length / AppConstants.pageSize).ceil().clamp(1, 9999);
    if (_currentPage >= totalPages) _currentPage = 0;
    final pageData = searched.skip(_currentPage * AppConstants.pageSize).take(AppConstants.pageSize).toList();

    return Column(
      children: [
        // Search + export bar
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          color: AppTheme.bgCard,
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchCtrl,
                  onChanged: (_) => setState(() => _currentPage = 0),
                  decoration: const InputDecoration(
                    hintText: 'Buscar caso, distribuidor, zona…',
                    prefixIcon: Icon(Icons.search, size: 18, color: AppTheme.textSecondary),
                    contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 14),
                  ),
                  style: const TextStyle(color: AppTheme.textPrimary, fontSize: 12),
                ),
              ),
              const SizedBox(width: 10),
              PopupMenuButton<String>(
                icon: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: AppTheme.fotonBlue,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Row(children: [
                    Icon(Icons.download, size: 14, color: Colors.white),
                    SizedBox(width: 4),
                    Text('Exportar', style: TextStyle(color: Colors.white, fontSize: 12)),
                  ]),
                ),
                color: AppTheme.bgCard2,
                itemBuilder: (_) => [
                  const PopupMenuItem(value: 'pdf', child: Row(children: [
                    Icon(Icons.picture_as_pdf, size: 16, color: AppTheme.semaforoRed),
                    SizedBox(width: 8),
                    Text('PDF', style: TextStyle(color: AppTheme.textPrimary, fontSize: 13)),
                  ])),
                  const PopupMenuItem(value: 'csv', child: Row(children: [
                    Icon(Icons.table_chart, size: 16, color: AppTheme.semaforoGreen),
                    SizedBox(width: 8),
                    Text('CSV / Excel', style: TextStyle(color: AppTheme.textPrimary, fontSize: 13)),
                  ])),
                ],
                onSelected: (v) async {
                  if (v == 'pdf') await ExportService.exportToPdf(searched, p.stats);
                  else await ExportService.exportToExcel(searched);
                },
              ),
            ],
          ),
        ),

        // Results count
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          color: AppTheme.bgDark,
          child: Row(
            children: [
              Text(
                '${searched.length} resultados · Página ${_currentPage + 1}/$totalPages',
                style: const TextStyle(color: AppTheme.textSecondary, fontSize: 11),
              ),
              const Spacer(),
              if (searched.isEmpty && _searchCtrl.text.isNotEmpty)
                TextButton(
                  onPressed: () { _searchCtrl.clear(); setState(() {}); },
                  child: const Text('Limpiar búsqueda', style: TextStyle(fontSize: 11)),
                ),
            ],
          ),
        ),

        // Table
        Expanded(
          child: searched.isEmpty
              ? _emptyState()
              : SingleChildScrollView(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: DataTable(
                      headingRowColor: WidgetStateProperty.all(AppTheme.bgCard2),
                      dataRowColor: WidgetStateProperty.resolveWith((s) =>
                          s.contains(WidgetState.hovered) ? AppTheme.fotonBlue.withOpacity(0.08) : null),
                      headingTextStyle: const TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.8,
                      ),
                      dataTextStyle: const TextStyle(color: AppTheme.textPrimary, fontSize: 12),
                      dividerThickness: 0.5,
                      columnSpacing: 16,
                      sortColumnIndex: _colIndex(_sortColumn),
                      sortAscending: _sortAsc,
                      columns: [
                        _col('CASO', 'caso'),
                        _col('FECHA', 'fecha'),
                        _col('ZONA', 'zona'),
                        _col('DISTRIBUIDOR', 'distribuidor'),
                        _col('MODELO', 'modelo'),
                        const DataColumn(label: Text('TIPO FALLA')),
                        _col('ESTATUS', 'estatus'),
                        const DataColumn(label: Text('RESPONSABLE')),
                        const DataColumn(label: Text('INMOV.')),
                        _col('DÍAS', 'dias'),
                      ],
                      rows: pageData.map((c) {
                        final days = c.dias;
                        final dayColor = days == null
                            ? AppTheme.textSecondary
                            : days <= 3
                                ? AppTheme.semaforoGreen
                                : days <= 7
                                    ? AppTheme.semaforoYellow
                                    : AppTheme.semaforoRed;
                        return DataRow(cells: [
                          DataCell(Text(c.caso, style: const TextStyle(fontWeight: FontWeight.w600))),
                          DataCell(Text(c.fechaDisplay)),
                          DataCell(Text(c.zona.isEmpty ? '—' : c.zona)),
                          DataCell(SizedBox(width: 130, child: Text(c.distribuidor.isEmpty ? '—' : c.distribuidor, overflow: TextOverflow.ellipsis))),
                          DataCell(Text(c.modelo.isEmpty ? '—' : c.modelo)),
                          DataCell(SizedBox(width: 130, child: Text(c.falla.isEmpty ? '—' : c.falla, overflow: TextOverflow.ellipsis))),
                          DataCell(_statusBadge(c)),
                          DataCell(SizedBox(width: 110, child: Text(c.responsable.isEmpty ? '—' : c.responsable, overflow: TextOverflow.ellipsis))),
                          DataCell(_inmovBadge(c.inmovilizante)),
                          DataCell(_daysBadge(c.diasDisplay, dayColor)),
                        ]);
                      }).toList(),
                    ),
                  ),
                ),
        ),

        // Pagination
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          color: AppTheme.bgCard,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _pageBtn(Icons.first_page, _currentPage > 0, () => setState(() => _currentPage = 0)),
              _pageBtn(Icons.chevron_left, _currentPage > 0, () => setState(() => _currentPage--)),
              const SizedBox(width: 12),
              Text(
                '${_currentPage + 1} / $totalPages',
                style: const TextStyle(color: AppTheme.textPrimary, fontSize: 12),
              ),
              const SizedBox(width: 12),
              _pageBtn(Icons.chevron_right, _currentPage < totalPages - 1, () => setState(() => _currentPage++)),
              _pageBtn(Icons.last_page, _currentPage < totalPages - 1, () => setState(() => _currentPage = totalPages - 1)),
            ],
          ),
        ),
      ],
    );
  }

  int _colIndex(String col) {
    const cols = ['caso', 'fecha', 'zona', 'distribuidor', 'modelo', '', 'estatus', '', '', 'dias'];
    return cols.indexOf(col).clamp(0, 9);
  }

  DataColumn _col(String label, String col) {
    return DataColumn(
      label: Text(label),
      onSort: (_, __) => _sort(col),
    );
  }

  Widget _statusBadge(CasoModel c) {
    final closed = c.isClosed;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: (closed ? AppTheme.semaforoGreen : AppTheme.semaforoYellow).withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: (closed ? AppTheme.semaforoGreen : AppTheme.semaforoYellow).withOpacity(0.3)),
      ),
      child: Text(
        c.estatus.isEmpty ? (closed ? 'Cerrado' : 'Abierto') : c.estatus,
        style: TextStyle(
          color: closed ? AppTheme.semaforoGreen : AppTheme.semaforoYellow,
          fontSize: 10, fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _inmovBadge(bool inmov) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: (inmov ? AppTheme.semaforoRed : AppTheme.fotonBlue).withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: (inmov ? AppTheme.semaforoRed : AppTheme.fotonBlue).withOpacity(0.3)),
      ),
      child: Text(
        inmov ? 'Sí' : 'No',
        style: TextStyle(
          color: inmov ? AppTheme.semaforoRed : AppTheme.fotonAccent,
          fontSize: 10, fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _daysBadge(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(
        label,
        style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w600),
      ),
    );
  }

  Widget _pageBtn(IconData icon, bool enabled, VoidCallback onTap) {
    return IconButton(
      onPressed: enabled ? onTap : null,
      icon: Icon(icon, size: 18),
      color: enabled ? AppTheme.fotonAccent : AppTheme.borderColor,
      padding: EdgeInsets.zero,
      constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
    );
  }

  Widget _emptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.search_off, size: 48, color: AppTheme.textSecondary),
          const SizedBox(height: 12),
          const Text('Sin resultados', style: TextStyle(color: AppTheme.textPrimary, fontSize: 16, fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          Text(
            'No se encontraron casos con "${_searchCtrl.text}"',
            style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
          ),
        ],
      ),
    );
  }
}
