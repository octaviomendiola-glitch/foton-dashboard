import 'package:flutter/material.dart';

class AppTheme {
  // FOTON Brand Colors
  static const Color fotonNavy = Color(0xFF003087);
  static const Color fotonBlue = Color(0xFF0057B8);
  static const Color fotonElectric = Color(0xFF0080E8);
  static const Color fotonAccent = Color(0xFF00AAFF);

  // Background
  static const Color bgDark = Color(0xFF06101E);
  static const Color bgCard = Color(0xFF0D1F3C);
  static const Color bgCard2 = Color(0xFF0F2347);
  static const Color borderColor = Color(0xFF1A3A6E);

  // Text
  static const Color textPrimary = Color(0xFFE8F0FF);
  static const Color textSecondary = Color(0xFF8AABCC);

  // Semaforo
  static const Color semaforoGreen = Color(0xFF00D97E);
  static const Color semaforoYellow = Color(0xFFFFBE2E);
  static const Color semaforoRed = Color(0xFFE8364A);

  // Chart palette
  static const List<Color> chartPalette = [
    Color(0xFF0080E8),
    Color(0xFF00AAFF),
    Color(0xFF003087),
    Color(0xFF0057B8),
    Color(0xFF00D97E),
    Color(0xFFFFBE2E),
    Color(0xFFE8364A),
    Color(0xFF7B61FF),
    Color(0xFFFF6B35),
    Color(0xFF00C9A7),
    Color(0xFFF5A623),
    Color(0xFF4A9EFF),
    Color(0xFF00E0BB),
    Color(0xFFFF6B9D),
    Color(0xFFC084FC),
  ];

  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bgDark,
      colorScheme: const ColorScheme.dark(
        primary: fotonElectric,
        secondary: fotonAccent,
        surface: bgCard,
        error: semaforoRed,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: bgDark,
        foregroundColor: textPrimary,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          color: textPrimary,
          fontSize: 16,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.5,
        ),
      ),
      cardTheme: CardThemeData(
        color: bgCard,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: const BorderSide(color: borderColor, width: 1),
        ),
        margin: EdgeInsets.zero,
      ),
      textTheme: const TextTheme(
        headlineLarge: TextStyle(
          color: textPrimary,
          fontSize: 28,
          fontWeight: FontWeight.w800,
          letterSpacing: 3,
        ),
        headlineMedium: TextStyle(
          color: textPrimary,
          fontSize: 20,
          fontWeight: FontWeight.w700,
        ),
        headlineSmall: TextStyle(
          color: textPrimary,
          fontSize: 16,
          fontWeight: FontWeight.w600,
        ),
        bodyLarge: TextStyle(color: textPrimary, fontSize: 14),
        bodyMedium: TextStyle(color: textSecondary, fontSize: 12),
        bodySmall: TextStyle(color: textSecondary, fontSize: 11),
        labelSmall: TextStyle(
          color: textSecondary,
          fontSize: 10,
          letterSpacing: 1,
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: fotonBlue,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
        ),
      ),
      dividerTheme: const DividerThemeData(
        color: borderColor,
        thickness: 1,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: bgDark,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: borderColor),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: borderColor),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: fotonAccent),
        ),
        hintStyle: const TextStyle(color: textSecondary, fontSize: 12),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: bgCard,
        selectedItemColor: fotonAccent,
        unselectedItemColor: textSecondary,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
      ),
    );
  }

  // Helper: semaforo color for days
  static Color semaforoColor(double? days) {
    if (days == null) return textSecondary;
    if (days <= 3) return semaforoGreen;
    if (days <= 7) return semaforoYellow;
    return semaforoRed;
  }

  static Color semaforoBackground(double? days) {
    if (days == null) return bgCard2;
    if (days <= 3) return const Color(0xFF051F14);
    if (days <= 7) return const Color(0xFF1E1400);
    return const Color(0xFF1E0308);
  }

  // Gradient
  static const LinearGradient fotonGradient = LinearGradient(
    colors: [fotonNavy, fotonElectric],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient accentGradient = LinearGradient(
    colors: [fotonBlue, fotonAccent],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );
}
