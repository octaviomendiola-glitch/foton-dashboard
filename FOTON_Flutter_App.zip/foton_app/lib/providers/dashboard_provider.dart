import 'package:flutter/foundation.dart';
import '../models/caso_model.dart';
import '../services/excel_service.dart';

class DashboardProvider extends ChangeNotifier {
  List<CasoModel> _allCasos = [];
  List<CasoModel> _filteredCasos = [];
  bool _loading = false;
  String? _error;
  String? _fileName;

  // Filters
  String? _filterZona;
  String? _filterDistribuidor;
  String? _filterEstatus;
  String? _filterModelo;

  // Getters
  List<CasoModel> get allCasos => _allCasos;
  List<CasoModel> get filteredCasos => _filteredCasos;
  bool get loading => _loading;
  String? get error => _error;
  String? get fileName => _fileName;
  bool get hasData => _allCasos.isNotEmpty;

  String? get filterZona => _filterZona;
  String? get filterDistribuidor => _filterDistribuidor;
  String? get filterEstatus => _filterEstatus;
  String? get filterModelo => _filterModelo;

  // Computed filter options
  List<String> get zonas => _uniqueSorted(_allCasos, (c) => c.zona);
  List<String> get distribuidores {
    final base = _filterZona != null
        ? _allCasos.where((c) => c.zona == _filterZona).toList()
        : _allCasos;
    return _uniqueSorted(base, (c) => c.distribuidor);
  }
  List<String> get estatuses => _uniqueSorted(_allCasos, (c) => c.estatus);
  List<String> get modelos => _uniqueSorted(_allCasos, (c) => c.modelo);

  // Computed stats
  DashboardStats get stats => DashboardStats.fromCasos(_filteredCasos);

  // Rankings
  List<DistribuidorRanking> get ranking =>
      DistribuidorRanking.fromCasos(_filteredCasos);

  // Chart data
  Map<String, int> get casosPorZona =>
      _countBy(_filteredCasos, (c) => c.zona);

  Map<String, int> get casosPorModelo =>
      _countBy(_filteredCasos, (c) => c.modelo);

  Map<String, int> get casosPorFalla =>
      _countBy(_filteredCasos, (c) => c.falla);

  Map<String, int> get casosPorMes =>
      _countBy(_filteredCasos, (c) => c.mesAnio)
        ..removeWhere((k, _) => k == 'Sin fecha');

  Map<String, double> get tiempoPorDistribuidor {
    final map = <String, List<double>>{};
    for (final c in _filteredCasos) {
      if (c.distribuidor.isEmpty || c.dias == null) continue;
      map.putIfAbsent(c.distribuidor, () => []).add(c.dias!);
    }
    return Map.fromEntries(
      map.entries
          .map((e) => MapEntry(
                e.key,
                e.value.reduce((a, b) => a + b) / e.value.length,
              ))
          .toList()
        ..sort((a, b) => b.value.compareTo(a.value)),
    );
  }

  // Heatmap data: distribuidor x falla
  Map<String, Map<String, int>> get heatmapData {
    final topDists = (_countBy(_filteredCasos, (c) => c.distribuidor).entries
            .toList()
          ..sort((a, b) => b.value.compareTo(a.value)))
        .take(10)
        .map((e) => e.key)
        .toList();
    final topFallas = (_countBy(_filteredCasos, (c) => c.falla).entries
            .toList()
          ..sort((a, b) => b.value.compareTo(a.value)))
        .take(10)
        .map((e) => e.key)
        .toList();

    final result = <String, Map<String, int>>{};
    for (final d in topDists) {
      result[d] = {for (final f in topFallas) f: 0};
    }
    for (final c in _filteredCasos) {
      if (result.containsKey(c.distribuidor) &&
          result[c.distribuidor]!.containsKey(c.falla)) {
        result[c.distribuidor]![c.falla] =
            result[c.distribuidor]![c.falla]! + 1;
      }
    }
    return result;
  }

  List<String> get heatmapFallas {
    return (_countBy(_filteredCasos, (c) => c.falla).entries.toList()
          ..sort((a, b) => b.value.compareTo(a.value)))
        .take(10)
        .map((e) => e.key)
        .toList();
  }

  // Load file
  Future<void> loadFile(String filePath) async {
    _loading = true;
    _error = null;
    notifyListeners();

    try {
      _allCasos = await ExcelService.parseFile(filePath);
      _fileName = filePath.split('/').last.split('\\').last;
      _clearFilters();
      _applyFilters();
    } catch (e) {
      _error = 'Error al procesar el archivo: $e';
      _allCasos = [];
      _filteredCasos = [];
    }

    _loading = false;
    notifyListeners();
  }

  // Filter setters
  void setFilterZona(String? v) {
    _filterZona = v;
    _filterDistribuidor = null; // reset distribuidor when zona changes
    _applyFilters();
    notifyListeners();
  }

  void setFilterDistribuidor(String? v) {
    _filterDistribuidor = v;
    _applyFilters();
    notifyListeners();
  }

  void setFilterEstatus(String? v) {
    _filterEstatus = v;
    _applyFilters();
    notifyListeners();
  }

  void setFilterModelo(String? v) {
    _filterModelo = v;
    _applyFilters();
    notifyListeners();
  }

  void resetFilters() {
    _clearFilters();
    _applyFilters();
    notifyListeners();
  }

  void _clearFilters() {
    _filterZona = null;
    _filterDistribuidor = null;
    _filterEstatus = null;
    _filterModelo = null;
  }

  void _applyFilters() {
    _filteredCasos = _allCasos.where((c) {
      if (_filterZona != null && c.zona != _filterZona) return false;
      if (_filterDistribuidor != null && c.distribuidor != _filterDistribuidor) return false;
      if (_filterEstatus != null && c.estatus != _filterEstatus) return false;
      if (_filterModelo != null && c.modelo != _filterModelo) return false;
      return true;
    }).toList();
  }

  static List<String> _uniqueSorted(
      List<CasoModel> list, String Function(CasoModel) fn) {
    return list
        .map(fn)
        .where((s) => s.isNotEmpty)
        .toSet()
        .toList()
      ..sort();
  }

  static Map<String, int> _countBy(
      List<CasoModel> list, String Function(CasoModel) fn) {
    final map = <String, int>{};
    for (final item in list) {
      final k = fn(item);
      if (k.isEmpty) continue;
      map[k] = (map[k] ?? 0) + 1;
    }
    return map;
  }
}
