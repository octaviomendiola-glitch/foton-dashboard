class AppConstants {
  static const String appName = 'Dashboard Ejecutivo';
  static const String appSubtitle = 'Soporte Técnico FOTON México';
  static const String appVersion = '1.0.0';

  // Column detection keywords
  static const Map<String, List<String>> columnKeywords = {
    'caso': ['caso', 'ticket', 'folio', 'id', 'número', 'numero', 'no.', 'num'],
    'fecha': ['fecha', 'date', 'apertura', 'inicio', 'creacion', 'creación', 'open'],
    'zona': ['zona', 'region', 'área', 'area', 'territorio'],
    'distribuidor': ['distribuidor', 'dealer', 'concesionario', 'distribuidora', 'nombre dist', 'agencia'],
    'modelo': ['modelo', 'model', 'unidad', 'vehículo', 'vehiculo', 'camion'],
    'falla': ['falla', 'tipo falla', 'tipo de falla', 'problema', 'descripcion', 'descripción', 'síntoma', 'sintoma', 'failure', 'averia'],
    'estatus': ['estatus', 'status', 'estado', 'situa'],
    'responsable': ['responsable', 'tecnico', 'técnico', 'asignado', 'asesor', 'encargado'],
    'dias': ['días', 'dias', 'tiempo', 'days', 'atención', 'atencion', 'duración', 'duracion', 'transcurrido'],
    'inmovilizante': ['inmovilizante', 'inmovil', 'critico', 'crítico', 'parado', 'immob'],
    'cierre': ['cierre', 'fecha cierre', 'fecha_cierre', 'closed', 'close'],
  };

  static const List<String> closedKeywords = [
    'cerr', 'close', 'resuel', 'finali', 'complet', 'cerrado', 'resuelto'
  ];

  static const List<String> inmovilizanteKeywords = [
    'si', 'sí', 'yes', '1', 'true', 'x', 'inmovilizante'
  ];

  static const int pageSize = 50;

  // Semaforo thresholds
  static const int semaforoGreenMax = 3;
  static const int semaforoYellowMax = 7;
}
