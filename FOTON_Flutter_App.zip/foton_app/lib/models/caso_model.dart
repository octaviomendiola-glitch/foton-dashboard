class CasoModel {
  final String caso;
  final DateTime? fecha;
  final String zona;
  final String distribuidor;
  final String modelo;
  final String falla;
  final String estatus;
  final String responsable;
  final bool inmovilizante;
  final double? dias;
  final Map<String, dynamic> rawData;

  CasoModel({
    required this.caso,
    this.fecha,
    required this.zona,
    required this.distribuidor,
    required this.modelo,
    required this.falla,
    required this.estatus,
    required this.responsable,
    required this.inmovilizante,
    this.dias,
    required this.rawData,
  });

  bool get isClosed {
    final s = estatus.toLowerCase();
    return s.contains('cerr') ||
        s.contains('close') ||
        s.contains('resuel') ||
        s.contains('finali') ||
        s.contains('complet');
  }

  String get semaforoLabel {
    if (dias == null) return '—';
    if (dias! <= 3) return 'Verde';
    if (dias! <= 7) return 'Amarillo';
    return 'Rojo';
  }

  String get diasDisplay {
    if (dias == null) return '—';
    return '${dias!.toStringAsFixed(0)} d';
  }

  String get fechaDisplay {
    if (fecha == null) return '—';
    return '${fecha!.day.toString().padLeft(2, '0')}/'
        '${fecha!.month.toString().padLeft(2, '0')}/'
        '${fecha!.year}';
  }

  String get mesAnio {
    if (fecha == null) return 'Sin fecha';
    return '${fecha!.year}-${fecha!.month.toString().padLeft(2, '0')}';
  }
}

// Stats summary model
class DashboardStats {
  final int total;
  final int abiertos;
  final int cerrados;
  final int inmovilizantes;
  final int distribuidores;
  final int modelos;
  final double? avgDias;
  final double? maxDias;
  final double? minDias;
  final double? mediana;
  final double? stdDev;
  final double? p90;
  final double? p95;
  final int semaforoVerde;
  final int semaforoAmarillo;
  final int semaforoRojo;

  DashboardStats({
    required this.total,
    required this.abiertos,
    required this.cerrados,
    required this.inmovilizantes,
    required this.distribuidores,
    required this.modelos,
    this.avgDias,
    this.maxDias,
    this.minDias,
    this.mediana,
    this.stdDev,
    this.p90,
    this.p95,
    required this.semaforoVerde,
    required this.semaforoAmarillo,
    required this.semaforoRojo,
  });

  double get pctCerrados => total > 0 ? cerrados / total * 100 : 0;
  double get pctInmovilizantes => total > 0 ? inmovilizantes / total * 100 : 0;

  static DashboardStats fromCasos(List<CasoModel> casos) {
    if (casos.isEmpty) {
      return DashboardStats(
        total: 0, abiertos: 0, cerrados: 0, inmovilizantes: 0,
        distribuidores: 0, modelos: 0,
        semaforoVerde: 0, semaforoAmarillo: 0, semaforoRojo: 0,
      );
    }

    final cerrados = casos.where((c) => c.isClosed).length;
    final inmov = casos.where((c) => c.inmovilizante).length;
    final dists = casos.map((c) => c.distribuidor).where((d) => d.isNotEmpty).toSet().length;
    final mods = casos.map((c) => c.modelo).where((m) => m.isNotEmpty).toSet().length;

    final diasArr = casos
        .map((c) => c.dias)
        .where((d) => d != null)
        .map((d) => d!)
        .toList()
      ..sort();

    double? avg, mx, mn, med, std, p90v, p95v;
    int verde = 0, amarillo = 0, rojo = 0;

    if (diasArr.isNotEmpty) {
      avg = diasArr.reduce((a, b) => a + b) / diasArr.length;
      mx = diasArr.last;
      mn = diasArr.first;

      final n = diasArr.length;
      if (n % 2 == 0) {
        med = (diasArr[n ~/ 2 - 1] + diasArr[n ~/ 2]) / 2;
      } else {
        med = diasArr[n ~/ 2];
      }

      final variance = diasArr.fold<double>(
              0, (prev, v) => prev + (v - avg!) * (v - avg!)) /
          (n > 1 ? n - 1 : 1);
      std = variance > 0 ? variance.sqrt() : 0;

      p90v = diasArr[(n * 0.90).floor().clamp(0, n - 1)];
      p95v = diasArr[(n * 0.95).floor().clamp(0, n - 1)];

      verde = diasArr.where((d) => d <= 3).length;
      amarillo = diasArr.where((d) => d > 3 && d <= 7).length;
      rojo = diasArr.where((d) => d > 7).length;
    }

    return DashboardStats(
      total: casos.length,
      abiertos: casos.length - cerrados,
      cerrados: cerrados,
      inmovilizantes: inmov,
      distribuidores: dists,
      modelos: mods,
      avgDias: avg,
      maxDias: mx,
      minDias: mn,
      mediana: med,
      stdDev: std,
      p90: p90v,
      p95: p95v,
      semaforoVerde: verde,
      semaforoAmarillo: amarillo,
      semaforoRojo: rojo,
    );
  }
}

extension on double {
  double sqrt() {
    if (this <= 0) return 0;
    double x = this;
    double y = 1.0;
    double e = 0.000001;
    while (x - y > e) {
      x = (x + y) / 2;
      y = this / x;
    }
    return x;
  }
}

// Distributor ranking model
class DistribuidorRanking {
  final String nombre;
  final int total;
  final int abiertos;
  final int cerrados;
  final double? avgDias;

  DistribuidorRanking({
    required this.nombre,
    required this.total,
    required this.abiertos,
    required this.cerrados,
    this.avgDias,
  });

  double get pctCumplimiento => total > 0 ? cerrados / total * 100 : 0;

  static List<DistribuidorRanking> fromCasos(List<CasoModel> casos) {
    final map = <String, List<CasoModel>>{};
    for (final c in casos) {
      if (c.distribuidor.isEmpty) continue;
      map.putIfAbsent(c.distribuidor, () => []).add(c);
    }

    return map.entries.map((e) {
      final list = e.value;
      final closed = list.where((c) => c.isClosed).length;
      final diasArr = list
          .map((c) => c.dias)
          .where((d) => d != null)
          .map((d) => d!)
          .toList();
      final avg = diasArr.isNotEmpty
          ? diasArr.reduce((a, b) => a + b) / diasArr.length
          : null;
      return DistribuidorRanking(
        nombre: e.key,
        total: list.length,
        abiertos: list.length - closed,
        cerrados: closed,
        avgDias: avg,
      );
    }).toList()
      ..sort((a, b) {
        final pctDiff = b.pctCumplimiento.compareTo(a.pctCumplimiento);
        if (pctDiff != 0) return pctDiff;
        return b.total.compareTo(a.total);
      });
  }
}
