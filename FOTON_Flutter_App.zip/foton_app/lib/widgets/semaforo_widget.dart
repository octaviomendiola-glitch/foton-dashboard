import 'package:flutter/material.dart';
import '../themes/app_theme.dart';

class SemaforoWidget extends StatelessWidget {
  final int verde;
  final int amarillo;
  final int rojo;

  const SemaforoWidget({
    super.key,
    required this.verde,
    required this.amarillo,
    required this.rojo,
  });

  @override
  Widget build(BuildContext context) {
    final total = verde + amarillo + rojo;
    return Row(
      children: [
        Expanded(child: _cell('Verde\n0–3 días', verde, total, AppTheme.semaforoGreen, const Color(0xFF051F14))),
        const SizedBox(width: 10),
        Expanded(child: _cell('Amarillo\n4–7 días', amarillo, total, AppTheme.semaforoYellow, const Color(0xFF1E1400))),
        const SizedBox(width: 10),
        Expanded(child: _cell('Rojo\n>7 días', rojo, total, AppTheme.semaforoRed, const Color(0xFF1E0308))),
      ],
    );
  }

  Widget _cell(String label, int count, int total, Color color, Color bg) {
    final pct = total > 0 ? (count / total * 100).toStringAsFixed(1) : '0.0';
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Column(
        children: [
          Container(
            width: 14, height: 14,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: color.withOpacity(0.5), blurRadius: 8)],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 10,
              color: color,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            count.toString(),
            style: const TextStyle(
              fontSize: 32,
              fontWeight: FontWeight.w700,
              color: Colors.white,
              height: 1,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            '$pct% de casos',
            style: const TextStyle(
              fontSize: 10,
              color: AppTheme.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}
