import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/dashboard_provider.dart';
import '../themes/app_theme.dart';

class FilterBar extends StatelessWidget {
  const FilterBar({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.watch<DashboardProvider>();
    return Container(
      color: AppTheme.bgCard,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _FilterChip(
              label: 'Zona',
              value: p.filterZona,
              options: p.zonas,
              onChanged: (v) => p.setFilterZona(v),
            ),
            const SizedBox(width: 10),
            _FilterChip(
              label: 'Distribuidor',
              value: p.filterDistribuidor,
              options: p.distribuidores,
              onChanged: (v) => p.setFilterDistribuidor(v),
            ),
            const SizedBox(width: 10),
            _FilterChip(
              label: 'Estatus',
              value: p.filterEstatus,
              options: p.estatuses,
              onChanged: (v) => p.setFilterEstatus(v),
            ),
            const SizedBox(width: 10),
            _FilterChip(
              label: 'Modelo',
              value: p.filterModelo,
              options: p.modelos,
              onChanged: (v) => p.setFilterModelo(v),
            ),
            const SizedBox(width: 10),
            // Records count badge
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: AppTheme.bgDark,
                border: Border.all(color: AppTheme.borderColor),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                '${p.filteredCasos.length} registros',
                style: const TextStyle(
                  fontSize: 11, color: AppTheme.textSecondary,
                ),
              ),
            ),
            const SizedBox(width: 10),
            // Reset button
            if (p.filterZona != null ||
                p.filterDistribuidor != null ||
                p.filterEstatus != null ||
                p.filterModelo != null)
              TextButton.icon(
                onPressed: p.resetFilters,
                icon: const Icon(Icons.clear, size: 14),
                label: const Text('Limpiar', style: TextStyle(fontSize: 11)),
                style: TextButton.styleFrom(
                  foregroundColor: AppTheme.textSecondary,
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final String? value;
  final List<String> options;
  final ValueChanged<String?> onChanged;

  const _FilterChip({
    required this.label,
    required this.value,
    required this.options,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final isActive = value != null;
    return GestureDetector(
      onTap: () => _showPicker(context),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isActive ? AppTheme.fotonBlue.withOpacity(0.2) : AppTheme.bgDark,
          border: Border.all(
            color: isActive ? AppTheme.fotonAccent : AppTheme.borderColor,
          ),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              isActive ? '$label: ${_short(value!)}' : label,
              style: TextStyle(
                fontSize: 11,
                color: isActive ? AppTheme.fotonAccent : AppTheme.textSecondary,
                fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
            const SizedBox(width: 4),
            Icon(
              Icons.arrow_drop_down,
              size: 16,
              color: isActive ? AppTheme.fotonAccent : AppTheme.textSecondary,
            ),
          ],
        ),
      ),
    );
  }

  String _short(String s) => s.length > 16 ? '${s.substring(0, 16)}…' : s;

  void _showPicker(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.bgCard2,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              margin: const EdgeInsets.only(top: 8),
              width: 40, height: 4,
              decoration: BoxDecoration(
                color: AppTheme.borderColor,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                'Filtrar por $label',
                style: const TextStyle(
                  fontSize: 14, fontWeight: FontWeight.w600, color: AppTheme.textPrimary,
                ),
              ),
            ),
            const Divider(color: AppTheme.borderColor, height: 1),
            ListTile(
              title: const Text('Todos', style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
              trailing: value == null ? const Icon(Icons.check, color: AppTheme.fotonAccent, size: 18) : null,
              onTap: () { Navigator.pop(context); onChanged(null); },
            ),
            Flexible(
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: options.length,
                itemBuilder: (_, i) {
                  final opt = options[i];
                  return ListTile(
                    title: Text(opt, style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13)),
                    trailing: value == opt ? const Icon(Icons.check, color: AppTheme.fotonAccent, size: 18) : null,
                    onTap: () { Navigator.pop(context); onChanged(opt); },
                  );
                },
              ),
            ),
            const SizedBox(height: 16),
          ],
        );
      },
    );
  }
}
