import 'package:flutter/material.dart';
import '../models/caso_model.dart';
import '../themes/app_theme.dart';

class RankingTable extends StatelessWidget {
  final List<DistribuidorRanking> ranking;
  final int maxTotal;

  const RankingTable({
    super.key,
    required this.ranking,
    required this.maxTotal,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: DataTable(
        headingRowColor: WidgetStateProperty.all(AppTheme.bgCard2),
        dataRowColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.hovered)) {
            return AppTheme.fotonBlue.withOpacity(0.1);
          }
          return Colors.transparent;
        }),
        headingTextStyle: const TextStyle(
          color: AppTheme.textSecondary,
          fontSize: 10,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.8,
        ),
        dataTextStyle: const TextStyle(
          color: AppTheme.textPrimary,
          fontSize: 12,
        ),
        dividerThickness: 0.5,
        columnSpacing: 20,
        columns: const [
          DataColumn(label: Text('#')),
          DataColumn(label: Text('DISTRIBUIDOR')),
          DataColumn(label: Text('TOTAL'), numeric: true),
          DataColumn(label: Text('ABIERTOS'), numeric: true),
          DataColumn(label: Text('CERRADOS'), numeric: true),
          DataColumn(label: Text('% CUMPL.')),
          DataColumn(label: Text('DÍAS PROM.'), numeric: true),
          DataColumn(label: Text('VOLUMEN')),
        ],
        rows: ranking.asMap().entries.map((e) {
          final i = e.key;
          final r = e.value;
          final pctColor = r.pctCumplimiento >= 90
              ? AppTheme.semaforoGreen
              : r.pctCumplimiento >= 70
                  ? AppTheme.semaforoYellow
                  : AppTheme.semaforoRed;
          final barW = maxTotal > 0 ? r.total / maxTotal : 0.0;

          return DataRow(cells: [
            DataCell(_rankBadge(i + 1)),
            DataCell(
              SizedBox(
                width: 140,
                child: Text(
                  r.nombre,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    color: AppTheme.textPrimary,
                    fontSize: 12,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
            DataCell(Text(r.total.toString())),
            DataCell(_badge(r.abiertos.toString(), AppTheme.semaforoYellow)),
            DataCell(_badge(r.cerrados.toString(), AppTheme.semaforoGreen)),
            DataCell(
              Text(
                '${r.pctCumplimiento.toStringAsFixed(1)}%',
                style: TextStyle(color: pctColor, fontWeight: FontWeight.w700),
              ),
            ),
            DataCell(Text(
              r.avgDias != null ? '${r.avgDias!.toStringAsFixed(1)} d' : '—',
            )),
            DataCell(
              SizedBox(
                width: 80,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(3),
                  child: LinearProgressIndicator(
                    value: barW.toDouble(),
                    backgroundColor: AppTheme.bgDark,
                    valueColor: const AlwaysStoppedAnimation(AppTheme.fotonAccent),
                    minHeight: 6,
                  ),
                ),
              ),
            ),
          ]);
        }).toList(),
      ),
    );
  }

  Widget _rankBadge(int rank) {
    Color bg, fg;
    if (rank == 1) { bg = const Color(0xFFFFD70022); fg = const Color(0xFFFFD700); }
    else if (rank == 2) { bg = const Color(0xFFC0C0C022); fg = const Color(0xFFC0C0C0); }
    else if (rank == 3) { bg = const Color(0xFFCD7F3222); fg = const Color(0xFFCD7F32); }
    else { bg = AppTheme.bgDark; fg = AppTheme.textSecondary; }

    return Container(
      width: 28, height: 28,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: bg,
        shape: BoxShape.circle,
        border: Border.all(color: fg.withOpacity(0.4)),
      ),
      child: Text(
        rank.toString(),
        style: TextStyle(color: fg, fontSize: 11, fontWeight: FontWeight.w700),
      ),
    );
  }

  Widget _badge(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontSize: 11,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
